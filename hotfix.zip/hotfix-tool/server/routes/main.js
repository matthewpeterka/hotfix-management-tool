const express = require('express')
const router = express.Router()
const Post = require('../models/Post')
const ldap = require('ldapjs')
const fs = require('fs').promises;
const doc = require('docx')
const json2csv = require('json2csv');
const { Document, Paragraph, Table, TableRow, TableCell, WidthType, HeightType, Image } = require('docx')
const path = require('path')

//comment out if using ldapjs
const auth = 'true'

/*
FUNCTION TO AUTHENNTICATE USING LDAPJS
*/
function authenticate(username, password){ 
    try {
        return new Promise((resolve, reject) => {
            //creates ldap client
            const client = ldap.createClient({
                url: 'ldap://amrldap01.emrsn.org'
            })
            //when an error occurs it will delete the client to stop crashing
            client.on('error', (err) => {
                console.log('error occured, most likely ldapjs timed out. ' + err)
                client.destroy()
                reject(new Error('ldapjs timed out'));
                
            })
            //will bind the user with the username and passsword
            client.bind(username, password, function(err) {
                if (err) {
                    reject(new Error('invalid credentials'));
                }
                else {
                    console.log('successfully authenticated')
                    resolve(1);
                }
            })

        })
    } catch (error) {
        console.log(error)
        return new Error('error authenticating user');
    }
}

/*
LOGIN PAGE
*/
router.post('/', async (req, res) => {
    //console.log(req.body.user)
    try {
        //call authentication function
        const test = await authenticate(req.body.user, req.body.pass)
        //creates cookie if the authentication is correct
        res.cookie('authenticated', true, {
            httpOnly: true,
            maxAge: 1800000,
            secure: true})
        //redirect to the database
        res.redirect('/hotfixes')
    } catch (error) {
        //outputs error for login
        console.log(error.message);
        //sends alert to the browser
        res.send(`
            <script>
                alert('Login failed. Please try again.');
                window.location.href = '/';
            </script>
        `);
    }
})

/*
LOGOUT PAGE
*/
router.post('/logout', (req, res) => {
    //logs the user out

    /*
    UNCOMMENT BELOW IF USING LDAPJS
    */
    // res.clearCookie('authenticated')
    // res.redirect('/')

    /*
    COMMENT OUT IF USING LDAPJS
    */
    res.redirect('/hotfixes')
})

/*
COOKIE TEST
*/
// router.get('/cookies', (req, res) => {
//     res.cookie('testing', true, { httpOnly: true });
//     console.log(req.cookies)
//     res.send(req.cookies)
// })

/*
GET HOME 
*/
router.get('', (req, res) => {
    //locals for the ejs page
    const locals = {
        title: "Homepage",
        description: "Homepage for hotfix database"
    }
    //clears cookie and loads page

    /*
    UNCOMMENT THIS CODE IF USING THE AUTHENTICATION LDAPJS
    */

    // res.clearCookie('authenticated')
    // res.status(200).render('pages/main', { layout: '../views/pages/main', locals })

    /*
    COMMENT THIS CODE OUT IF USING THE AUTHENTICATION LDAPJS
    */
    res.cookie('authenticated', true, {
        httpOnly: true,
        maxAge: 1800000,
        secure: true}).redirect('/hotfixes')
})

/*
POST SEARCH 
*/
router.post('/search', async (req, res) => {
    //console.log(req.body.searchCriteria)
    if (auth === 'true') {
        //will check if the item in database matches the search term
        try {
            const ip = req.socket.remoteAddress
            console.log('post request for SEARCH made by ip: ' + ip)
            const searchTerm = req.body.searchTerm
            if (searchTerm === '') {
                res.redirect('/hotfixes')
            }
            const locals = {
                title: "Hotfixes",
                description: "Filtered Hotfix Database"
            }
            let data
            if (searchTerm.includes("?") || searchTerm.includes("$") || searchTerm.includes("+") || searchTerm.includes("\\")) {
                if (req.body.searchCriteria === "hms_request") {
                    data = await Post.find({
                        hms_request: { $in: searchTerm }
                    }).sort({"date": -1})
                }
                else if (req.body.searchCriteria === "hms_bug") {
                    data = await Post.find({
                        hms_bug: { $in: searchTerm }
                    }).sort({"date": -1})
                }
                else if (req.body.searchCriteria === "azure_devops") {
                    data = await Post.find({
                        azure_devops: { $in: searchTerm }
                    }).sort({"date": -1})
                }
                else if (req.body.searchCriteria === "version") {
                    data = await Post.find({
                        version: { $in: searchTerm }
                    }).sort({"date": -1})
                }
                else if (req.body.searchCriteria === "line") {
                    data = await Post.find({
                        line: { $in: searchTerm }
                    }).sort({"date": -1})
                }
                else if (req.body.searchCriteria === "commit_id") {
                    data = await Post.find({
                        commit_id: { $in: searchTerm }
                    }).sort({"date": -1})
                }
                else if (req.body.searchCriteria === "pull_id") {
                    data = await Post.find({
                        pull_id: { $in: searchTerm }
                    }).sort({"date": -1})
                }
                else if (req.body.searchCriteria === "build_instr") {
                    data = await Post.find({
                        build_instr: { $in: searchTerm }
                    }).sort({"date": -1})
                }
                else if (req.body.searchCriteria === "nonbuild_rsrc") {
                    data = await Post.find({
                        nonbuild_rsrc: { $in: searchTerm }
                    }).sort({"date": -1})
                }
                else if (req.body.searchCriteria === "deliverables") {
                    data = await Post.find({
                        deliverables: { $in: searchTerm }
                    }).sort({"date": -1})
                }
                else if (req.body.searchCriteria === "t3") {
                    data = await Post.find({
                        t3: { $in: searchTerm }
                    }).sort({"date": -1})
                }
                else if (req.body.searchCriteria === "owner") {
                    data = await Post.find({
                        owner: { $in: searchTerm }
                    }).sort({"date": -1})
                }
                else if (req.body.searchCriteria === "special_instr") {
                    data = await Post.find({
                        special_instr: { $in: searchTerm }
                    }).sort({"date": -1})
                }
            }
            else {
                if (req.body.searchCriteria === "hms_request") {
                    data = await Post.find({
                        hms_request: { $regex: searchTerm }
                    }).sort({"date": -1})
                }
                else if (req.body.searchCriteria === "hms_bug") {
                    data = await Post.find({
                        hms_bug: { $regex: searchTerm }
                    }).sort({"date": -1})
                }
                else if (req.body.searchCriteria === "azure_devops") {
                    data = await Post.find({
                        azure_devops: { $regex: searchTerm }
                    }).sort({"date": -1})
                }
                else if (req.body.searchCriteria === "version") {
                    data = await Post.find({
                        version: { $regex: searchTerm }
                    }).sort({"date": -1})
                }
                else if (req.body.searchCriteria === "line") {
                    data = await Post.find({
                        line: { $regex: searchTerm }
                    }).sort({"date": -1})
                }
                else if (req.body.searchCriteria === "commit_id") {
                    data = await Post.find({
                        commit_id: { $regex: searchTerm }
                    }).sort({"date": -1})
                }
                else if (req.body.searchCriteria === "pull_id") {
                    data = await Post.find({
                        pull_id: { $regex: searchTerm }
                    }).sort({"date": -1})
                }
                else if (req.body.searchCriteria === "build_instr") {
                    data = await Post.find({
                        build_instr: { $regex: searchTerm }
                    }).sort({"date": -1})
                }
                else if (req.body.searchCriteria === "nonbuild_rsrc") {
                    data = await Post.find({
                        nonbuild_rsrc: { $regex: searchTerm }
                    }).sort({"date": -1})
                }
                else if (req.body.searchCriteria === "deliverables") {
                    data = await Post.find({
                        deliverables: { $regex: searchTerm }
                    }).sort({"date": -1})
                }
                else if (req.body.searchCriteria === "t3") {
                    data = await Post.find({
                        t3: { $regex: searchTerm }
                    }).sort({"date": -1})
                }
                else if (req.body.searchCriteria === "owner") {
                    data = await Post.find({
                        owner: { $regex: searchTerm }
                    }).sort({"date": -1})
                }
                else if (req.body.searchCriteria === "special_instr") {
                    data = await Post.find({
                        special_instr: { $regex: searchTerm }
                    }).sort({"date": -1})
                }
            }
            res.status(200).render('pages/filtered_data', {layout: '../views/pages/filtered_data', locals, data})
        } catch (error) {
            console.log(error)
            res.status(500).json({ error: 'Internal server error' })
        }
    }
    else {
        res.redirect('/')
    }
})

/*
GET HOTFIXES 
*/
router.get('/hotfixes', async (req, res) => {
    const locals = {
        title: "Hotfixes",
        description: "Hotfix Database"
    }
    if (auth === 'true') {
        try {
            //gets the data in descending order and renders the page
            const data = await Post.find().sort({"date": -1})
            //console.log(data)
            res.status(200).render('pages/data', { layout: '../views/pages/data', locals, data});
        } catch (error) {
            console.log(error)
        }
    }
    else {
        res.redirect('/')
    }

})

/*
INSERT HOTFIXES
*/
function insertHotfixData() {
    //test for inserting one post
    Post.insertMany([
        {
            hms_request: "Testing",
            hms_bug: "Testing",
            azure_devops: "Testing",
            version: "Testing",
            line: "Testing",
            commit_id: [1, 2],
            pull_id: [1, 2],
            build_instr: [1, 32948],
            nonbuild_rsrc: [1, 2],
            deliverables: [1, 2],
            t3: "Testing",
            owner: "Timmy",
            special_instr: "Fire"
        }
        

    ])
}
//insertHotfixData();

/*
POST EXPORT DATA 
*/
router.post('/export_data', async (req, res) => {
    const locals = {
        title: "Hotfixes",
        description: "Exporting Hotfix Database"
    }
    if (auth === 'true') {
        try {
            const ip = req.socket.remoteAddress
            console.log('post request for EXPORT DATA made by ip: ' + ip)
            //finds the posts in descending order
            const data = await Post.find().sort({"date": -1})
            try {
                //writes a new file with the entire database
                await fs.writeFile('exported_data.json', JSON.stringify(data))
                console.log('exported data successfuly')
            }
            catch (error) {
                console.log(error)
            }
            //sends the file to the browser
            res.setHeader('Content-Type', 'application/json');
            res.setHeader('Content-Disposition', 'attachment; filename="exported_data.json"');
            res.sendFile(path.join(__dirname, '..', '..', 'exported_data.json'))
        } catch (error) {
            console.log(error)
        }
    }
    else {
        res.redirect('/')
    }
    //console.log("hotfix")

})

/*
POST IMPORT DATA 
*/
router.post('/import_data', async (req, res) => {
    const locals = {
        title: "Hotfixes",
        description: "Exporting Hotfix Database"
    }
    if (auth === 'true') {
        try {
            //gets the data
            const data = await Post.find().sort({"date": -1})
            const ip = req.socket.remoteAddress
            console.log('post request for IMPORT DATA made by ip: ' + ip)
            try {
                //reads the json file for input data
                const data = await fs.readFile('exported_data.json')
                const docs = await JSON.parse(data.toString())
                const duplicates = []
                //console.log(docs)
                const newDocs = []
                //loops throuugh and removes duplicates
                if (Array.isArray(docs) && typeof docs[0] === 'object') { // check if docs is an array of objects
                    for (const doc of docs) {
                        const existingDoc = await Post.findOne(doc)
                        
                        if (existingDoc) {
                            duplicates.push(doc)
                        } else {
                            newDocs.push(doc)
                        }
                    }
                    console.log(newDocs)
                    //insert the new data that is not a duplicate
                    const result = await Post.insertMany(newDocs)
                    console.log('imported data successfully')
                    res.redirect('/hotfixes')
                } else {
                    //if there is a single doc
                    const existingDoc = await Post.findOne(docs)
                    if (!existingDoc) {
                        const result = await Post.create(docs)
                    }
                    
                    res.redirect('/hotfixes')
                }
            }
            catch (error) {
                console.log(error)
                res.redirect('/hotfixes')
            }

        } catch (error) {
            console.log(error)
            res.redirect('/hotfixes')
        }
    }
    else {
        res.redirect('/')
    }
    //console.log("hotfix")
})

/*
CREATE NEW POST IN JS
*/
router.get('/add-hotfix', async (req, res) => {
    const locals = {
        title: "Add a Hotfix",
        description: "Adding a hotfix"
    }
    if (auth === 'true') {
        try {
            //gets the data and renders the add page
            const data = await Post.find()
            res.status(200).render('pages/add-hotfix', {layout: '../views/pages/add-hotfix', locals, data})
        } catch (error) {
            console.log(error)
        }
    }
    else {
        res.redirect('/')
    }
}) 

/*
CREATE NEW POST FROM WEBSITE
*/
router.post('/add-hotfix', async (req, res) => {
    if (auth === 'true') {
        try {
            //console.log(req.body)
            try {
                const ip = req.socket.remoteAddress
                console.log('post request for ADD HOTFIX made by ip: ' + ip)
                //gets the date and uploads a new hotfix to the database
                const date = new Date().toJSON().slice(0, 10)
                const newHotfix = new Post({
                    date: '' + date,
                    hms_request: req.body.hms_request.split('\r\n').filter(Boolean),
                    hms_bug: req.body.hms_bug.split('\r\n').filter(Boolean),
                    azure_devops: req.body.azure_devops.split('\r\n').filter(Boolean),
                    version: req.body.version.split('\r\n').filter(Boolean),
                    line: req.body.line.split('\r\n').filter(Boolean),
                    commit_id: req.body.commit_id.split('\r\n').filter(Boolean),
                    pull_id: req.body.pull_id.split('\r\n').filter(Boolean),
                    build_instr: req.body.build_instr.split('\r\n').filter(Boolean),
                    nonbuild_rsrc: req.body.nonbuild_rsrc.split('\r\n').filter(Boolean),
                    deliverables: req.body.deliverables.split('\r\n').filter(Boolean),
                    t3: req.body.t3.split('\r\n').filter(Boolean),
                    owner: req.body.owner.split('\r\n').filter(Boolean),
                    special_instr: req.body.special_instr.split('\r\n').filter(Boolean)
                })
    
                await Post.create(newHotfix)
                res.redirect('/hotfixes')
    
            } catch (error) {
                console.log(error)
            }
        } catch (error) {
            console.log(error)
        }
    }
    else {
        res.redirect('/')
    }
})

/*
GET MANAGE HOTFIX
*/
router.get('/edit-hotfix/:id', async (req, res) => {
    //console.log(req.body)
    if (auth === 'true') {
        try {

            const locals = {
                title: "Manage a Hotfix",
                description: "Managing a hotfix",
            }
            //loads the page with the current data by the id
            const data = await Post.findOne( {_id: req.params.id })
            if (data === null) {
                res.redirect('/hotfixes')
            }
            else {
                res.status(200).render('pages/edit-hotfix', {layout: '../views/pages/edit-hotfix', locals, data})
            }
        } catch (error) {
            console.log(error)
        }
    }
    else {
        res.redirect('/')
    }
})

/*
PUT/EDIT HOTFIX
*/
router.post('/edit-hotfix/:id', async (req, res) => {
    if (auth === 'true') {
        try {
            //finds the post by id and updates it with the post data
            const ip = req.socket.remoteAddress
            console.log('post request for EDIT HOTFIX made by ip: ' + ip)
            const data = await Post.findById(req.params.id)
            //console.log(data)
            //console.log(req.body)
            await Post.findByIdAndUpdate(req.params.id, {
                hms_request: req.body.hms_request.split('\r\n').filter(Boolean),
                hms_bug: req.body.hms_bug.split('\r\n').filter(Boolean),
                azure_devops: req.body.azure_devops.split('\r\n').filter(Boolean),
                version: req.body.version.split('\r\n').filter(Boolean),
                line: req.body.line.split('\r\n').filter(Boolean),
                commit_id: req.body.commit_id.split('\r\n').filter(Boolean),
                pull_id: req.body.pull_id.split('\r\n').filter(Boolean),
                build_instr: req.body.build_instr.split('\r\n').filter(Boolean),
                nonbuild_rsrc: req.body.nonbuild_rsrc.split('\r\n').filter(Boolean),
                deliverables: req.body.deliverables.split('\r\n').filter(Boolean),
                t3: req.body.t3.split('\r\n').filter(Boolean),
                owner: req.body.owner.split('\r\n').filter(Boolean),
                special_instr: req.body.special_instr.split('\r\n').filter(Boolean)
            })
    
            res.status(200).redirect('/hotfixes')
            //res.status(200).render('pages/data', {layout: '../views/pages/add-hotfix'})
        } catch (error) {
            console.log(error)
        }
    }
    else {
        res.redirect('/')
    }
})

/*
PUT/EDIT HOTFIX
*/
router.put('/edit-hotfix/:id', async (req, res) => {
    //console.log(req.body)
    if (auth === 'true') {
        try {
            await Post.findByIdAndUpdate(req.params.id, {
                hms_request: req.body.hms_request,
                hms_bug: req.body.hms_bug,
                azure_devops: req.body.azure_devops,
                version: req.body.version,
                line: req.body.line,
                commit_id: req.body.commit_id,
                pull_id: req.body.pull_id,
                build_instr: req.body.build_instr,
                nonbuild_rsrc: req.body.nonbuild_rsrc,
                deliverables: req.body.deliverables,
                t3: req.body.t3,
                owner: req.body.owner,
                special_instr: req.body.special_instr
            })
    
            res.status(200).redirect('/hotfixes')
            //res.status(200).render('pages/data', {layout: '../views/pages/add-hotfix'})
        } catch (error) {
            console.log(error)
        }
    }
    else {
        res.redirect('/')
    }
})


/*
DELETE HOTFIX
*/
router.delete('/delete-hotfix/:id', async (req, res) => {
    if (auth === 'true') {
        try{
            //deletes the selected hotfix
            await Post.deleteOne( {_id: req.params.id})
            res.redirect('/hotfixes')
        }
        catch (error) {
            console.log(error)
        }
    }
    else {
        res.redirect('/')
    }
})

/*
DELETE HOTFIX
*/
router.post('/delete-hotfix/:id', async (req, res) => {
    if (auth === 'true') {
        try{
            const ip = req.socket.remoteAddress
            console.log('post request for DELETE made by ip: ' + ip)
            //console.log(req.params.id)
            await Post.deleteOne( {_id: req.params.id})
            res.redirect('/hotfixes')
        }
        catch (error) {
            console.log(error)
        }
    }
    else {
        res.redirect('/')
    }
})

/*
ASCENDING HOTFIXES
*/
router.post('/ascending_hotfix', async (req, res) => {
    const locals = {
        title: "Hotfixes",
        description: "Hotfix Database"
    }
    if (auth === 'true') {
        try {
            const ip = req.socket.remoteAddress
            console.log('post request for ASCENDING HOTFIX made by ip: ' + ip)
            //gets the data in ascending order and renders the page
            const data = await Post.find().sort({"date": 1})
            //console.log(data)
            res.status(200).render('pages/data', { layout: '../views/pages/data', locals, data });
        } catch (error) {
            console.log(error)
        }
    }
    else {
        res.redirect('/')
    }
})

/*
DESCENDING HOTFIXES
*/
router.post('/descending_hotfix', async (req, res) => {
    const locals = {
        title: "Hotfixes",
        description: "Hotfix Database"
    }
    if (auth === 'true') {
        try {
            const ip = req.socket.remoteAddress
            console.log('post request for DESCENDING HOTFIX made by ip: ' + ip)
            //gets the data in descending order and renders the page
            const data = await Post.find().sort({"date": -1})
            //console.log(data)
            res.status(200).render('pages/data', { layout: '../views/pages/data', locals, data });
        } catch (error) {
            console.log(error)
        }
    }
    else {
        res.redirect('/')
    }
})

/*
DOWNLOAOD JSON
*/
router.post('/json-hotfix/:id', async (req, res) => {
    const locals = {
        title: "Download a hotfix as a json",
        description: "json hotfix"
    }
    if (auth === 'true') {
        try {
            const ip = req.socket.remoteAddress
            console.log('post request for JSON EXPORT made by ip: ' + ip)
            //gets the data for the hotfix
            const data = await Post.findById({_id: req.params.id})
            if (data === null) {
                res.redirect('/hotfixes')
            }
            /*
            CREATE A NEW JSON FOR THE HOTFIX
            */
            let hotfix = {
                date: data.date,
                hms_request: data.hms_request,
                hms_bug: data.hms_bug,
                azure_devops: data.azure_devops,
                version: data.version,
                line: data.line,
                commit_id: data.commit_id,
                pull_id: data.pull_id,
                build_instr: data.build_instr,
                nonbuild_rsrc: data.nonbuild_rsrc,
                deliverables: data.deliverables,
                t3: data.t3,
                owner: data.owner,
                special_instr: data.special_instr
            }
            //sends file to browser
            res.setHeader('Content-Type', 'application/json');
            res.setHeader('Content-Disposition', 'attachment; filename="hotfix.json"');
    
            res.json(hotfix);
    
        } catch (error) {
            console.log(error)
        }
    }
    else {
        res.redirect('/')
    }
})

/*
DOWNLOAD CSV
*/
router.post('/csv-hotfix/:id', async (req, res) => {
    const locals = {
        title: "Download hotfix as a csv",
        description: "csv hotfix"
    }
    if (auth === 'true') {
        try {
            const ip = req.socket.remoteAddress
            console.log('post request for CSV EXPORT made by ip: ' + ip)
            //gets the hotfix
            const data = await Post.findById({_id: req.params.id})
            if (data === null) {
                res.redirect('/hotfixes')
            }
            /*
            CREATE A NEW CSV FOR THE HOTFIX
            */
            const fields = ['date', 'hms_request', 'hms_bug', 'azure_devops', 'version', 'line', 'commit_id', 'pull_id', 'build_instr', 'nonbuild_rsrc', 'deliverables', 't3', 'owner', 'special_instr']
            const csv = json2csv.parse(data, {fields})
    
            res.setHeader('Content-Type', 'text/csv')
            res.setHeader('Content-Disposition', 'attachment; filename="hotfix.csv"')
            res.send(csv)
            
    
        } catch (error) {
            console.log(error)
        }
    }
    else {
        res.redirect('/')
    }
})

/*
DOWNLOAD DOCX
*/
router.post('/docx-hotfix/:id', async (req, res) => {
    const locals = {
        title: "Download hotfix as a docx",
        description: "docx hotfix"
    }
    if (auth === 'true') {
        try {
            const ip = req.socket.remoteAddress
            console.log('post request for DOCX EXPORT made by ip: ' + ip)
            const data = await Post.findById({_id: req.params.id})
            if (data === null) {
                res.redirect('/hotfixes')
            }
            /*
            CREATE DOCX FILE
            */
            const title = new doc.Paragraph({
                text: "Hotfix",
                heading: doc.HeadingLevel.HEADING_1,
                alignment: doc.HorizontalPositionAlign.CENTER
            })
    
            const table = new doc.Table({
                    rows: [
                        new doc.TableRow({
                            children: [
                                new doc.TableCell({
                                    children: [new doc.Paragraph("HMS Request")],
                                }),
                                new doc.TableCell({
                                    children: [
                                        ...data.hms_request.map((item) => {
                                            return new doc.Paragraph(item);
                                        })
                                    ],
                                }),
                            ],
                        }),
                        new doc.TableRow({
                            children: [
                                new doc.TableCell({
                                    children: [new doc.Paragraph("HMS Bug")],
                                }),
                                new doc.TableCell({
                                    children: [
                                        ...data.hms_bug.map((item) => {
                                            return new doc.Paragraph(item);
                                        })
                                    ],
                                }),
                            ],
                        }),
                        new doc.TableRow({
                            children: [
                                new doc.TableCell({
                                    children: [new doc.Paragraph("Azure DevOps Bug")],
                                }),
                                new doc.TableCell({
                                    children: [
                                        ...data.azure_devops.map((item) => {
                                            return new doc.Paragraph(item);
                                        })
                                    ],
                                }),
                            ],
                        }),
                        new doc.TableRow({
                            children: [
                                new doc.TableCell({
                                    children: [new doc.Paragraph("Product Version")],
                                }),
                                new doc.TableCell({
                                    children: [
                                        ...data.version.map((item) => {
                                            return new doc.Paragraph(item);
                                        })
                                    ],
                                }),
                            ],
                        }),
                        new doc.TableRow({
                            children: [
                                new doc.TableCell({
                                    children: [new doc.Paragraph("Product Line")],
                                }),
                                new doc.TableCell({
                                    children: [
                                        ...data.line.map((item) => {
                                            return new doc.Paragraph(item);
                                        })
                                    ],
                                }),
                            ],
                        }),
                        new doc.TableRow({
                            children: [
                                new doc.TableCell({
                                    children: [new doc.Paragraph("Commit IDs")],
                                }),
                                new doc.TableCell({
                                    children: [
                                        ...data.commit_id.map((item) => {
                                            return new doc.Paragraph(item);
                                        })
                                    ],
                                }),
                            ],
                        }),
                        new doc.TableRow({
                            children: [
                                new doc.TableCell({
                                    children: [new doc.Paragraph("Pull Request IDs")],
                                }),
                                new doc.TableCell({
                                    children: [
                                        ...data.pull_id.map((item) => {
                                            return new doc.Paragraph(item);
                                        })
                                    ],
                                }),
                            ],
                        }),
                        new doc.TableRow({
                            children: [
                                new doc.TableCell({
                                    children: [new doc.Paragraph("Build Instructions")],
                                }),
                                new doc.TableCell({
                                    children: [
                                        ...data.build_instr.map((item) => {
                                            return new doc.Paragraph(item);
                                        })
                                    ],
                                }),
                            ],
                        }),
                        new doc.TableRow({
                            children: [
                                new doc.TableCell({
                                    children: [new doc.Paragraph("Non-build Resources")],
                                }),
                                new doc.TableCell({
                                    children: [
                                        ...data.nonbuild_rsrc.map((item) => {
                                            return new doc.Paragraph(item);
                                        })
                                    ],
                                }),
                            ],
                        }),
                        new doc.TableRow({
                            children: [
                                new doc.TableCell({
                                    children: [new doc.Paragraph("Deliverables")],
                                }),
                                new doc.TableCell({
                                    children: [
                                        ...data.deliverables.map((item) => {
                                            return new doc.Paragraph(item);
                                        })
                                    ],
                                }),
                            ],
                        }),
                        new doc.TableRow({
                            children: [
                                new doc.TableCell({
                                    children: [new doc.Paragraph("T3 Project Code")],
                                }),
                                new doc.TableCell({
                                    children: [
                                        ...data.t3.map((item) => {
                                            return new doc.Paragraph(item);
                                        })
                                    ],
                                }),
                            ],
                        }),
                        new doc.TableRow({
                            children: [
                                new doc.TableCell({
                                    children: [new doc.Paragraph("Owner")],
                                }),
                                new doc.TableCell({
                                    children: [
                                        ...data.owner.map((item) => {
                                            return new doc.Paragraph(item);
                                        })
                                    ],
                                }),
                            ],
                        }),
                        new doc.TableRow({
                            children: [
                                new doc.TableCell({
                                    children: [new doc.Paragraph("Special Instructions")],
                                }),
                                new doc.TableCell({
                                    children: [
                                        ...data.special_instr.map((item) => {
                                            return new doc.Paragraph(item);
                                        })
                                    ],
                                }),
                            ],
                        }),
                    ],
                    width: {
                        size: 102,
                        type: WidthType.PERCENTAGE,
                    },
                    height: {
                        size: 100,
                        type: WidthType.PERCENTAGE,
                    }
            })
    
            const image = new doc.ImageRun({
                data: fs.readFile(path.join(__dirname, '..', '..', 'public', 'img', 'Emerson_Electric_Company.svg.png')),
                transformation: {
                    width: 75,
                    height: 25,
                },
            })
    
            const document = new doc.Document({
                sections: [{
                    properties: {},
                    children: [
                        new Paragraph({
                            children: [image],
                        }),
                        title,
                        table
                    ],
                }],
            })
    
            const buffer = await doc.Packer.toBuffer(document)
            await fs.writeFile(__dirname + '/hotfix.docx', buffer)
    
            res.attachment('hotfix.docx')
            res.setHeader('Content-Type', 'application/vnd.openxmlformats-officedocument.wordprocessingml.document')
            res.sendFile(__dirname + '/hotfix.docx');
    
        } catch (error) {
            console.log(error)
        }
    }
    else {
        res.redirect('/')
    }
    
})
module.exports = router