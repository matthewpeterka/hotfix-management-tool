var Service = require('node-windows').Service;
var svc = new Service({
    name:'build-sign database',
    description: 'Node.js service description goes here.',
    script: 'C:\\Users\\E1444555\\Desktop\\hotfix-tool\\index.js'
});

svc.on('install',function(){
    svc.start();
});

svc.install();