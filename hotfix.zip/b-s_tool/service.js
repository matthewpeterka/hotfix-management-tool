var Service = require('node-windows').Service;
var svc = new Service({
    name:'hotfix database',
    description: 'Node.js service description goes here.',
    script: 'C:\\Users\\testadmin\\Desktop\\mongo_test\\index.js'
});

svc.on('install',function(){
    svc.start();
});

svc.install();