var Service = require('node-windows').Service;
var svc = new Service({
    name:'build-sign database',
    description: 'Node.js service description goes here.',
    script: 'C:\\Users\\testadmin\\Desktop\\b-s_tool\\index.js'
});

svc.on('install',function(){
    svc.start();
});

svc.install();