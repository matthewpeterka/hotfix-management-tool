const express = require('express')
const router = express.Router()
const Post = require('../models/Post')

/*
GET HOME 
*/
router.get('', (req, res) => {
    const locals = {
        title: "Homepage",
        description: "Homepage for hotfix database"
    }
    //console.log("homepage")
    res.status(200).render('pages/main', { layout: '../views/pages/main', locals })
})

/*
POST SEARCH 
*/
router.post('/search', async (req, res) => {
    try {
        const searchTerm = req.body.searchTerm
        const locals = {
            title: "Hotfixes",
            description: "Filtered Hotfix Database"
        }
        const data = await Post.find({
            $or: [
                { hms_request: { $in: searchTerm } },
                { hms_bug: { $in: searchTerm } },
                { azure_devops: { $in: searchTerm } },
                { version: { $in: searchTerm } },
                { line: { $in: searchTerm } },
                { commit_id: { $in: searchTerm } },
                { pull_id: { $in: searchTerm } },
                { build_instr: { $in: searchTerm } },
                { nonbuild_rsrc: { $in: searchTerm } },
                { deliverables: { $in: searchTerm } },
                { t3: { $in: searchTerm } },
                { owner: { $in: searchTerm } },
                { special_instr: { $in: searchTerm } }
            ]
        });
        res.status(200).render('pages/filtered_data', {layout: '../views/pages/filtered_data', locals, data})
    } catch (error) {
        console.log(error)
        res.status(500).json({ error: 'Internal server error' })
    }
})

/*
GET HOTFIXES 
*/
router.get('/hotfixes', async (req, res) => {
    const locals = {
        title: "Hotfixes",
        description: "Hotfix Database"
    }
    //console.log("hotfix")
    try {
        const data = await Post.find()
        res.status(200).render('pages/data', {layout: '../views/pages/data', locals, data})
    } catch (error) {
        console.log(error)
    }
})

/*
INSERT HOTFIXES
*/
function insertHotfixData() {
    Post.insertMany([
        {
            hms_request: "Testing",
            hms_bug: "Testing",
            azure_devops: "Testing",
            version: "Testing",
            line: "Testing",
            commit_id: [1, 2],
            pull_id: [1, 2],
            build_instr: [1, 32948],
            nonbuild_rsrc: [1, 2],
            deliverables: [1, 2],
            t3: "Testing",
            owner: "Timmy",
            special_instr: "Fire"
        }
        

    ])
}

/*
CREATE NEW POST IN JS
*/
router.get('/add-hotfix', async (req, res) => {
    const locals = {
        title: "Add a Hotfix",
        description: "Adding a hotfix"
    }
    //console.log("hotfix")
    try {
        const data = await Post.find()
        res.status(200).render('pages/add-hotfix', {layout: '../views/pages/add-hotfix', locals, data})
    } catch (error) {
        console.log(error)
    }
})
//insertHotfixData();

/*
CREATE NEW POST FROM WEBSITE
*/
router.post('/add-hotfix', async (req, res) => {
    try {
        //console.log(req.body)
        try {
            const newHotfix = new Post({
                hms_request: req.body.hms_request,
                hms_bug: req.body.hms_bug,
                azure_devops: req.body.azure_devops,
                version: req.body.version,
                line: req.body.line,
                commit_id: req.body.commit_id.split('\r\n').filter(Boolean),
                pull_id: req.body.pull_id.split('\r\n').filter(Boolean),
                build_instr: req.body.build_instr.split('\r\n').filter(Boolean),
                nonbuild_rsrc: req.body.nonbuild_rsrc.split('\r\n').filter(Boolean),
                deliverables: req.body.deliverables.split('\r\n').filter(Boolean),
                t3: req.body.t3.split('\r\n').filter(Boolean),
                owner: req.body.owner,
                special_instr: req.body.special_instr
            })

            await Post.create(newHotfix)
            res.redirect('/hotfixes')

        } catch (error) {
            console.log(error)
        }
    } catch (error) {
        console.log(error)
    }
})


/*
GET EDIT HOTFIX
*/
router.get('/edit-hotfix/:id', async (req, res) => {
    //console.log(req.body)
    try {

        const locals = {
            title: "Edit a Hotfix",
            description: "Editing a hotfix",
        }
        
        const data = await Post.findOne( {_id: req.params.id })
        //console.log(data.commit_id)
        //console.log("ehere")
        res.status(200).render('pages/edit-hotfix', {layout: '../views/pages/edit-hotfix', locals, data})

    } catch (error) {
        console.log(error)
    }
})

/*
PUT/EDIT HOTFIX
*/
router.post('/edit-hotfix/:id', async (req, res) => {
    try {
        await Post.findByIdAndUpdate(req.params.id, {
            hms_request: req.body.hms_request,
            hms_bug: req.body.hms_bug,
            azure_devops: req.body.azure_devops,
            version: req.body.version,
            line: req.body.line,
            commit_id: req.body.commit_id.split('\r\n').filter(Boolean),
            pull_id: req.body.pull_id.split('\r\n').filter(Boolean),
            build_instr: req.body.build_instr.split('\r\n').filter(Boolean),
            nonbuild_rsrc: req.body.nonbuild_rsrc.split('\r\n').filter(Boolean),
            deliverables: req.body.deliverables.split('\r\n').filter(Boolean),
            t3: req.body.t3.split('\r\n').filter(Boolean),
            owner: req.body.owner,
            special_instr: req.body.special_instr
        })

        res.status(200).redirect('/hotfixes')
        //res.status(200).render('pages/data', {layout: '../views/pages/add-hotfix'})
    } catch (error) {
        console.log(error)
    }
})

/*
PUT/EDIT HOTFIX
*/
router.put('/edit-hotfix/:id', async (req, res) => {
    //console.log(req.body)
    try {
        await Post.findByIdAndUpdate(req.params.id, {
            hms_request: req.body.hms_request,
            hms_bug: req.body.hms_bug,
            azure_devops: req.body.azure_devops,
            version: req.body.version,
            line: req.body.line,
            commit_id: req.body.commit_id,
            pull_id: req.body.pull_id,
            build_instr: req.body.build_instr,
            nonbuild_rsrc: req.body.nonbuild_rsrc,
            deliverables: req.body.deliverables,
            t3: req.body.t3,
            owner: req.body.owner,
            special_instr: req.body.special_instr
        })

        res.status(200).redirect('/hotfixes')
        //res.status(200).render('pages/data', {layout: '../views/pages/add-hotfix'})
    } catch (error) {
        console.log(error)
    }
})


/*
DELETE HOTFIX
*/
router.delete('/delete-hotfix/:id', async (req, res) => {
    //console.log(req.body)
    try{
        
        await Post.deleteOne( {_id: req.params.id})
        res.redirect('/hotfixes')
    }
    catch (error) {
        console.log(error)
    }
})

/*
DELETE HOTFIX
*/
router.post('/delete-hotfix/:id', async (req, res) => {
    //console.log(req.body)
    try{
        
        await Post.deleteOne( {_id: req.params.id})
        res.redirect('/hotfixes')
    }
    catch (error) {
        console.log(error)
    }
})

module.exports = router