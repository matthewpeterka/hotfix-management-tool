const mongoose = require('mongoose')

const Schema = mongoose.Schema
const PostSchema = new Schema({
    date: {
        type: Array,
        required: true
    },
    hms_request: {
        type: Array,
        required: true
    },
    hms_bug: {
        type: Array,
        required: true
    },
    azure_devops: {
        type: Array,
        required: true
    },
    version: {
        type: Array,
        required: true
    },
    line: {
        type: Array,
        required: true
    },
    commit_id: {
        type: Array,
        required: true
    },
    pull_id: {
        type: Array,
        required: true
    },
    build_instr: {
        type: Array,
        required: true
    },
    nonbuild_rsrc: {
        type: Array,
        required: true
    },
    deliverables: {
        type: Array,
        required: true
    },
    t3: {
        type: Array,
        required: true
    },
    owner: {
        type: Array,
        required: true
    },
    special_instr: {
        type: Array,
        required: true
    }
})

module.exports = mongoose.model('hotfixes', PostSchema)
