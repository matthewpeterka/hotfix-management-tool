var Service = require('node-windows').Service;
var svc = new Service({
    name:'hotfix database',
    description: 'Node.js service description goes here.',
    script: 'C:\\Users\\E1444555\\Desktop\\mongo_test\\index.js'
});

svc.on('install',function(){
    svc.start();
});

svc.install();