const express = require('express')
const session = require('express-session');
const cookieParser = require('cookie-parser');
const port = 3000

require('dotenv').config()

//initialize app
const expressLayout = require('express-ejs-layouts')
const app = express()

app.use(express.json())
app.set('view engine', 'ejs');
app.use(express.static('public'))

app.set('layout', './pages/main')

app.use(expressLayout)

const methodOverride = require('method-override')

const connectDb = require('./server/config/db')

// db connection
connectDb()

app.use(cookieParser())
app.use(express.urlencoded({ extended: true}))
app.use(express.json())
app.use('/', require('./server/routes/main'))
app.use('/hotfixes', require('./server/routes/main'))
app.use(methodOverride('_method'))
app.use(cookieParser())
app.use(session({
    secret: 'ySecret',
    resave: false,
    saveUninitialized: true
}));


app.listen(port, () => {
    console.log("App lisening on port " + port)
})

