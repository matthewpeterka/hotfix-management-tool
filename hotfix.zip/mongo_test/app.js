const express = require('express')


require('dotenv').config()

//initialize app
const expressLayout = require('express-ejs-layouts')
const app = express()

app.use(express.json())
app.set('view engine', 'ejs');
app.use(express.static('public'))

app.set('layout', './pages/main')

app.use(expressLayout)

const methodOverride = require('method-override')

const connectDb = require('./server/config/db')

// db connection
connectDb()

app.use(express.urlencoded({ extended: true}))
app.use(express.json())
app.use('/', require('./server/routes/main'))
app.use('/hotfixes', require('./server/routes/main'))
app.use(methodOverride('_method'))


app.listen(3000, () => {
    console.log("App lisening on port 3000")
})

