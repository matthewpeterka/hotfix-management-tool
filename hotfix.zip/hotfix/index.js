const express = require('express')


require('dotenv').config()

//initialize app
const expressLayout = require('express-ejs-layouts')
const index = express()

index.use(express.json())
index.set('view engine', 'ejs');
index.use(express.static('public'))

index.set('layout', './pages/main')

index.use(expressLayout)

const methodOverride = require('method-override')

const connectDb = require('./server/config/db')

// db connection
connectDb()

index.use(express.urlencoded({ extended: true}))
index.use(express.json())
index.use('/', require('./server/routes/main'))
index.use('/hotfixes', require('./server/routes/main'))
index.use(methodOverride('_method'))


index.listen(3000, () => {
    console.log("App lisening on port 3000")
})

