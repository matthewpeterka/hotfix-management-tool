const mongoose = require('mongoose')

const Schema = mongoose.Schema
const PostSchema = new Schema({
    hms_request: {
        type: String,
        required: true
    },
    hms_bug: {
        type: String,
        required: true
    },
    azure_devops: {
        type: String,
        required: true
    },
    version: {
        type: String,
        required: true
    },
    line: {
        type: String,
        required: true
    },
    commit_id: {
        type: Array,
        required: true
    },
    pull_id: {
        type: Array,
        required: true
    },
    build_instr: {
        type: Array,
        required: true
    },
    nonbuild_rsrc: {
        type: Array,
        required: true
    },
    deliverables: {
        type: Array,
        required: true
    },
    t3: {
        type: String,
        required: true
    },
    owner: {
        type: String,
        required: true
    },
    special_instr: {
        type: String,
        required: true
    }
})

module.exports = mongoose.model('hotfixes', PostSchema)
